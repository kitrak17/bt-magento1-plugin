<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Braintree\Test\Unit\Model\Report;

/**
 * Class BraintreeSearchNodeStub
 */
class BraintreeSearchNodeStub
{
}
